const Algo = require("../algo");

describe("Algo", () => {
  describe("reverse", () => {

  });

  describe("isPalindrome", () => {
   
  });

  describe("capitalize", () => {
    
  });
});
