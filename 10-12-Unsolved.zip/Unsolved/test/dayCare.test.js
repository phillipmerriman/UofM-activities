const DayCare = require("../dayCare");
const Child = require("../child");

describe("DayCare", () => {
  
});
